<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student = currentStudent();
$studyDB = getStudyDB();

// Fetch courses from DB based on student's programme, year, semester
$stmt = $studyDB->prepare("
    SELECT c.course_id, c.course_name, c.description, c.icon, c.credit_hours
    FROM courses c
    JOIN programmes p ON c.programme_id = p.programme_id
    WHERE p.programme_name = ?
      AND c.year_offered   = ?
      AND c.semester       = ?
    ORDER BY c.course_id
");
$stmt->execute([$student['programme'], $student['year_of_study'], $student['semester']]);
$courses = $stmt->fetchAll();

// Fetch stats
$statsStmt = $studyDB->prepare("
    SELECT
        COUNT(DISTINCT qa.quiz_id) AS quizzes_done,
        ROUND(AVG(qa.score / qa.total * 100), 0) AS avg_score
    FROM quiz_attempts qa
    WHERE qa.student_id = ?
");
$statsStmt->execute([$student['student_id']]);
$stats = $statsStmt->fetch();

$totalUnits = $studyDB->prepare("
    SELECT COUNT(u.unit_id) AS total
    FROM units u
    JOIN courses c ON u.course_id = c.course_id
    JOIN programmes p ON c.programme_id = p.programme_id
    WHERE p.programme_name = ? AND c.year_offered = ? AND c.semester = ?
");
$totalUnits->execute([$student['programme'], $student['year_of_study'], $student['semester']]);
$unitCount = $totalUnits->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — Home</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.home-hero{padding:64px 7% 52px;border-bottom:1px solid var(--color-border);}
.year-chip{display:inline-flex;align-items:center;gap:6px;background:var(--color-surface);border:1px solid var(--color-border2);font-size:12px;color:var(--color-muted);padding:5px 14px;border-radius:100px;margin-bottom:20px;}
.year-chip strong{color:var(--color-green);font-weight:500;}
.home-hero h1{font-family:var(--font-display);font-size:clamp(36px,5vw,56px);font-weight:400;line-height:1.15;letter-spacing:-1px;margin-bottom:10px;}
.home-hero h1 em{font-style:italic;color:var(--color-accent);}
.home-hero p{font-size:15px;color:var(--color-muted);max-width:420px;}
.courses-section{padding:48px 7% 72px;}
.courses-section h2{font-size:11px;letter-spacing:0.12em;text-transform:uppercase;color:var(--color-muted);margin-bottom:28px;font-weight:400;}
.courses-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;}
.course-card{border:1px solid var(--color-border);border-radius:14px;padding:28px 26px;cursor:pointer;background:#fff;transition:border-color .25s,transform .2s,box-shadow .25s;position:relative;overflow:hidden;text-decoration:none;display:block;color:inherit;}
.course-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--color-accent);opacity:0;transition:opacity .25s;}
.course-card:hover{border-color:var(--color-border2);transform:translateY(-3px);box-shadow:0 10px 32px rgba(0,0,0,.07);}
.course-card:hover::before{opacity:1;}
.course-icon{font-size:28px;margin-bottom:16px;}
.course-card h3{font-family:var(--font-display);font-size:20px;font-weight:400;letter-spacing:-.3px;margin-bottom:6px;}
.course-card p{font-size:13px;color:var(--color-muted);margin-bottom:20px;line-height:1.55;}
.course-meta{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:var(--color-muted);}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php" title="View Profile"><?= htmlspecialchars($student['initials']) ?></a>
        <a class="btn-ghost" href="php/logout.php">Sign out</a>
    </div>
</nav>

<div class="home-hero">
    <div class="year-chip">📍 <strong><?= $student['year_of_study'] ?><?= ['','st','nd','rd','th'][$student['year_of_study']] ?> Year</strong> · <?= htmlspecialchars($student['programme']) ?></div>
    <h1>Hey <?= htmlspecialchars(explode(' ', $student['full_name'])[0]) ?>,<br>what do you want to <em>study today?</em></h1>
    <p>You have <?= count($courses) ?> courses this semester. Pick one to get started.</p>
</div>

<div class="courses-section">
    <h2>Your Courses</h2>
    <div class="courses-grid">
        <?php foreach ($courses as $course): ?>
        <a class="course-card" href="course.php?id=<?= $course['course_id'] ?>">
            <div class="course-icon"><?= $course['icon'] ?></div>
            <h3><?= htmlspecialchars($course['course_name']) ?></h3>
            <p><?= htmlspecialchars($course['description']) ?></p>
            <div class="course-meta">
                <span>📚 <?= $course['credit_hours'] ?> credit hrs</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:0%"></div></div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
