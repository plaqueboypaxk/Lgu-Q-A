<?php
// ============================================================
//  session.php — Session Management & Page Protection
// ============================================================

function startSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Call this at the top of every protected page
function requireLogin() {
    startSession();
    if (empty($_SESSION['student_id'])) {
        header('Location: index.html');
        exit;
    }
}

// Store student data in session after login
function setSessionStudent($student) {
    $_SESSION['student_id']    = $student['student_id'];
    $_SESSION['username']      = $student['username'];
    $_SESSION['full_name']     = $student['full_name'];
    $_SESSION['programme']     = $student['programme'];
    $_SESSION['year_of_study'] = $student['year_of_study'];
    $_SESSION['semester']      = $student['semester'];
    $_SESSION['initials']      = getInitials($student['full_name']);
}

function getInitials($name) {
    $parts = explode(' ', trim($name));
    $initials = '';
    foreach ($parts as $part) {
        $initials .= strtoupper(substr($part, 0, 1));
    }
    return substr($initials, 0, 2);
}

function currentStudent() {
    startSession();
    return [
        'student_id'    => $_SESSION['student_id']    ?? '',
        'username'      => $_SESSION['username']       ?? '',
        'full_name'     => $_SESSION['full_name']      ?? '',
        'programme'     => $_SESSION['programme']      ?? '',
        'year_of_study' => $_SESSION['year_of_study']  ?? '',
        'semester'      => $_SESSION['semester']       ?? '',
        'initials'      => $_SESSION['initials']       ?? '',
    ];
}
