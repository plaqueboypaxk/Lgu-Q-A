<?php
// ============================================================
//  php/login.php — Login Handler
//  Called via POST from index.html form
// ============================================================

require_once '../includes/db.php';
require_once '../includes/session.php';

startSession();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$username   = trim($_POST['username'] ?? '');
$student_id = trim($_POST['student_id'] ?? '');
$password   = $_POST['password'] ?? '';

// Basic validation
if (!$username || !$student_id || !$password) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

try {
    $studyDB  = getStudyDB();
    $schoolDB = getSchoolDB();

    // 1. Find student account in study DB
    $stmt = $studyDB->prepare("
        SELECT student_id, username, password
        FROM students
        WHERE username = ? AND student_id = ?
    ");
    $stmt->execute([$username, $student_id]);
    $account = $stmt->fetch();

    if (!$account || !password_verify($password, $account['password'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid username, student ID, or password.']);
        exit;
    }

    // 2. Fetch current info from school DB
    $stmt = $schoolDB->prepare("
        SELECT full_name, programme, year_of_study, semester, status
        FROM school_students
        WHERE student_id = ?
    ");
    $stmt->execute([$account['student_id']]);
    $schoolInfo = $stmt->fetch();

    if (!$schoolInfo) {
        echo json_encode(['success' => false, 'error' => 'Student not found in school database.']);
        exit;
    }

    if ($schoolInfo['status'] !== 'active') {
        echo json_encode(['success' => false, 'error' => 'Your account is ' . $schoolInfo['status'] . '. Please contact the registrar.']);
        exit;
    }

    // 3. Update last login
    $studyDB->prepare("UPDATE students SET last_login = NOW() WHERE student_id = ?")
            ->execute([$account['student_id']]);

    // 4. Set session
    setSessionStudent([
        'student_id'    => $account['student_id'],
        'username'      => $account['username'],
        'full_name'     => $schoolInfo['full_name'],
        'programme'     => $schoolInfo['programme'],
        'year_of_study' => $schoolInfo['year_of_study'],
        'semester'      => $schoolInfo['semester'],
    ]);

    echo json_encode(['success' => true, 'redirect' => 'home.php']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'A server error occurred. Please try again.']);
}
