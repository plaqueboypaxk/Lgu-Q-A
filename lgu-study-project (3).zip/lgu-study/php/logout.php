<?php
// ============================================================
//  php/logout.php — Destroys session and redirects to login
// ============================================================

require_once '../includes/session.php';
startSession();
session_destroy();
header('Location: ../index.html');
exit;
