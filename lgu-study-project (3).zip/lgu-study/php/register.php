<?php
// ============================================================
//  php/register.php — Register Handler
//  Verifies student against school DB before creating account
// ============================================================

require_once '../includes/db.php';
require_once '../includes/session.php';

startSession();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$full_name   = trim($_POST['full_name']   ?? '');
$student_id  = trim($_POST['student_id']  ?? '');
$username    = trim($_POST['username']    ?? '');
$password    = $_POST['password']         ?? '';
$confirm     = $_POST['confirm_password'] ?? '';

// Validation
if (!$full_name || !$student_id || !$username || !$password || !$confirm) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

if ($password !== $confirm) {
    echo json_encode(['success' => false, 'error' => 'Passwords do not match.']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'error' => 'Password must be at least 6 characters.']);
    exit;
}

if (!preg_match('/^[a-zA-Z0-9._]+$/', $username)) {
    echo json_encode(['success' => false, 'error' => 'Username can only contain letters, numbers, dots, and underscores.']);
    exit;
}

try {
    $studyDB  = getStudyDB();
    $schoolDB = getSchoolDB();

    // 1. Verify student exists in school DB and name matches
    $stmt = $schoolDB->prepare("
        SELECT student_id, full_name, programme, year_of_study, semester, status
        FROM school_students
        WHERE student_id = ?
    ");
    $stmt->execute([$student_id]);
    $schoolStudent = $stmt->fetch();

    if (!$schoolStudent) {
        echo json_encode(['success' => false, 'error' => 'Student ID not found in the school database. Please contact the registrar.']);
        exit;
    }

    if ($schoolStudent['status'] !== 'active') {
        echo json_encode(['success' => false, 'error' => 'Your enrollment status is ' . $schoolStudent['status'] . '. Please contact the registrar.']);
        exit;
    }

    // Check name matches (case-insensitive)
    if (strtolower(trim($schoolStudent['full_name'])) !== strtolower($full_name)) {
        echo json_encode(['success' => false, 'error' => 'Full name does not match school records. Please enter your name exactly as registered.']);
        exit;
    }

    // 2. Check if student already has an account
    $stmt = $studyDB->prepare("SELECT student_id FROM students WHERE student_id = ?");
    $stmt->execute([$student_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'An account for this Student ID already exists. Please sign in instead.']);
        exit;
    }

    // 3. Check username not already taken
    $stmt = $studyDB->prepare("SELECT username FROM students WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'That username is already taken. Please choose another.']);
        exit;
    }

    // 4. Hash password and create account
    $hashed = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $studyDB->prepare("
        INSERT INTO students (student_id, username, password, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$student_id, $username, $hashed]);

    // 5. Set session and redirect
    setSessionStudent([
        'student_id'    => $student_id,
        'username'      => $username,
        'full_name'     => $schoolStudent['full_name'],
        'programme'     => $schoolStudent['programme'],
        'year_of_study' => $schoolStudent['year_of_study'],
        'semester'      => $schoolStudent['semester'],
    ]);

    echo json_encode(['success' => true, 'redirect' => 'home.php']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'A server error occurred. Please try again.']);
}
