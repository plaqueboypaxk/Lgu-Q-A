// ── SHARED DATA ──────────────────────────────────────────────

const courses = {
    bcom: { title:'Business Communication', desc:'Covers types, models, and strategies for effective communication in professional settings.', icon:'💬', progress:40, unitsDone:'2 / 6', sidebarProgress:'33%',
        units:[{title:'Types of Communication',desc:'6 topics · 5 min read'},{title:'Ways to Communicate',desc:'4 topics · 6 min read'},{title:'Communication Models',desc:'5 topics · 8 min read'},{title:'Barriers to Communication',desc:'4 topics · 5 min read'},{title:'Written Communication',desc:'7 topics · 10 min read'},{title:'Presentation Skills',desc:'5 topics · 7 min read'}]},
    ds:   { title:'Data Structures', desc:'Arrays, linked lists, stacks, queues, trees, and graphs with algorithm analysis.', icon:'🔢', progress:15, unitsDone:'1 / 8', sidebarProgress:'12%',
        units:[{title:'Arrays & Strings',desc:'5 topics · 6 min read'},{title:'Linked Lists',desc:'6 topics · 8 min read'},{title:'Stacks & Queues',desc:'4 topics · 5 min read'},{title:'Trees & Binary Trees',desc:'7 topics · 10 min read'},{title:'Graphs',desc:'5 topics · 9 min read'},{title:'Hash Tables',desc:'4 topics · 6 min read'},{title:'Sorting Algorithms',desc:'6 topics · 8 min read'},{title:'Big-O Analysis',desc:'3 topics · 5 min read'}]},
    web:  { title:'Web Development', desc:'HTML, CSS, JavaScript, PHP, and database integration for full-stack development.', icon:'🌐', progress:60, unitsDone:'4 / 7', sidebarProgress:'57%',
        units:[{title:'HTML Fundamentals',desc:'5 topics · 4 min read'},{title:'CSS Layouts & Styling',desc:'8 topics · 10 min read'},{title:'JavaScript Basics',desc:'6 topics · 8 min read'},{title:'DOM Manipulation',desc:'5 topics · 6 min read'},{title:'PHP & Server-side',desc:'7 topics · 9 min read'},{title:'MySQL Integration',desc:'5 topics · 7 min read'},{title:'Full-stack Project',desc:'4 topics · 12 min read'}]},
    db:   { title:'Database Management', desc:'Relational databases, SQL, normalization, transactions, and database design.', icon:'🗄️', progress:0, unitsDone:'0 / 5', sidebarProgress:'0%',
        units:[{title:'Introduction to DBMS',desc:'4 topics · 5 min read'},{title:'Entity-Relationship Models',desc:'5 topics · 7 min read'},{title:'SQL Queries',desc:'8 topics · 10 min read'},{title:'Normalization',desc:'5 topics · 8 min read'},{title:'Transactions & ACID',desc:'4 topics · 6 min read'}]},
    os:   { title:'Operating Systems', desc:'Process management, memory, file systems, and concurrency in modern OS design.', icon:'⚙️', progress:25, unitsDone:'1 / 6', sidebarProgress:'17%',
        units:[{title:'OS Overview',desc:'3 topics · 4 min read'},{title:'Process Management',desc:'6 topics · 8 min read'},{title:'Memory Management',desc:'5 topics · 7 min read'},{title:'File Systems',desc:'4 topics · 5 min read'},{title:'Concurrency & Deadlocks',desc:'6 topics · 9 min read'},{title:'I/O Systems',desc:'3 topics · 4 min read'}]},
    net:  { title:'Computer Networks', desc:'OSI model, TCP/IP, routing, switching, and network security fundamentals.', icon:'📡', progress:5, unitsDone:'0 / 5', sidebarProgress:'5%',
        units:[{title:'Network Fundamentals',desc:'4 topics · 5 min read'},{title:'OSI & TCP/IP Models',desc:'6 topics · 8 min read'},{title:'Routing & Switching',desc:'5 topics · 7 min read'},{title:'Network Protocols',desc:'6 topics · 9 min read'},{title:'Network Security',desc:'5 topics · 6 min read'}]}
};

const unitNotes = {
    0: { h:'Types of Communication', body:`<h3>What is Communication?</h3><p>Communication is the process of transferring information, ideas, feelings, and thoughts between a sender and a receiver through a chosen medium.</p><div class="callout">💡 Effective communication requires not just sending a message — but ensuring it is received and understood correctly.</div><h3>Verbal Communication</h3><p>Verbal communication uses spoken or written words. It includes face-to-face conversations, phone calls, presentations, and written correspondence.</p><ul><li>Oral — speeches, meetings, interviews</li><li>Written — emails, reports, letters</li><li>Clarity, tone, and language choice are critical</li></ul><h3>Non-Verbal Communication</h3><p>Signals conveyed without words — body language, facial expressions, eye contact, posture, gestures. Research suggests over 70% of communication is non-verbal.</p><h3>Formal vs Informal</h3><p>Formal follows official channels — memos, reports, official meetings. Informal is spontaneous — hallway conversations, messaging apps.</p>` },
    1: { h:'Ways to Communicate', body:`<h3>Communication Channels</h3><p>A communication channel is the medium through which a message travels from sender to receiver. Choosing the right channel is essential for effective communication.</p><div class="callout">📌 Match your channel to your message. Sensitive feedback works best face-to-face; routine updates work well over email.</div><h3>Face-to-Face Communication</h3><p>The richest communication channel. Allows for immediate feedback, non-verbal cues, and emotional connection.</p><h3>Digital Communication</h3><p>Includes email, messaging apps, video calls, and social platforms. Enables asynchronous communication across distances.</p><ul><li>Email — formal, documented, asynchronous</li><li>Instant messaging — quick, informal, real-time</li><li>Video conferencing — combines visual and audio remotely</li></ul>` }
};

const quizData = {
    course: [
        {q:'Which type of communication involves body language and facial expressions?', opts:['Verbal communication','Non-verbal communication','Written communication','Formal communication'], ans:1},
        {q:'What is the primary purpose of business communication?', opts:['Entertainment','To convey information effectively in a professional context','Social interaction','Personal expression'], ans:1},
        {q:'Which of the following is an example of formal communication?', opts:['A text message to a friend','A hallway conversation','An official memo to staff','A social media post'], ans:2},
        {q:'In the communication process, who encodes the message?', opts:['The receiver','The medium','The sender','The feedback'], ans:2},
        {q:'Which communication channel is considered richest?', opts:['Email','Text message','Face-to-face','Phone call'], ans:2}
    ],
    unit: [
        {q:'What percentage of communication is estimated to be non-verbal?', opts:['20%','45%','Over 70%','90%'], ans:2},
        {q:'Which of the following is NOT a form of verbal communication?', opts:['A speech','A letter','A gesture','A phone call'], ans:2},
        {q:'Formal communication follows which structure?', opts:['Random and spontaneous','Official channels and hierarchies','Peer-to-peer informal networks','Social media patterns'], ans:1},
        {q:'What is the key factor for effective verbal communication?', opts:['Speed of delivery','Clarity, tone, and language choice','Volume of voice','Use of technical terms'], ans:1},
        {q:'Which best describes informal communication?', opts:['Official memos','Structured reports','Spontaneous and unofficial interaction','Formal presentations'], ans:2}
    ]
};

// ── SESSION HELPERS ───────────────────────────────────────────
// Store current selections in sessionStorage so pages share state

function saveSession(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value));
}

function loadSession(key) {
    const val = sessionStorage.getItem(key);
    return val ? JSON.parse(val) : null;
}

// ── NAV HELPER ────────────────────────────────────────────────
function buildNav(activePage) {
    return `
    <nav class="app-nav">
        <a class="nav-logo" href="home.html">LGU <em>Study.</em></a>
        <div class="nav-right">
            <span class="nav-name">Alex Mwape</span>
            <a class="avatar" href="profile.html" title="View Profile">AM</a>
            <a class="btn-ghost" href="index.html">Sign out</a>
        </div>
    </nav>`;
}

// ── QUIZ ENGINE ───────────────────────────────────────────────
let currentQuiz = [], currentQ = 0, selectedAnswer = null;
let correctCount = 0, wrongCount = 0, skippedCount = 0;
let timerInterval = null, timeLeft = 120;

function initQuiz(type) {
    currentQuiz = quizData[type] || quizData.unit;
    currentQ = 0; correctCount = 0; wrongCount = 0; skippedCount = 0;
    saveSession('quizType', type);
    renderQuestion();
    startTimer();
}

function renderQuestion() {
    const q = currentQuiz[currentQ];
    document.getElementById('q-num').textContent   = currentQ + 1;
    document.getElementById('q-total').textContent = currentQuiz.length;
    document.getElementById('q-label').textContent = `Question ${String(currentQ+1).padStart(2,'0')}`;
    document.getElementById('q-text').textContent  = q.q;
    document.getElementById('quiz-progress').style.width = ((currentQ+1) / currentQuiz.length * 100) + '%';
    selectedAnswer = null;
    document.getElementById('btn-next').classList.remove('ready');
    const letters = ['A','B','C','D'];
    document.getElementById('q-options').innerHTML = q.opts.map((o,i) =>
        `<div class="option" onclick="selectOption(${i})" id="opt-${i}">
            <div class="option-letter">${letters[i]}</div><span>${o}</span>
        </div>`
    ).join('');
}

function selectOption(i) {
    if (selectedAnswer !== null) return;
    selectedAnswer = i;
    document.getElementById('btn-next').classList.add('ready');
    document.querySelectorAll('.option').forEach(o => o.classList.remove('selected'));
    document.getElementById('opt-' + i).classList.add('selected');
}

function nextQuestion() {
    if (selectedAnswer === null) {
        skippedCount++;
    } else {
        if (selectedAnswer === currentQuiz[currentQ].ans) correctCount++;
        else {
            wrongCount++;
            document.querySelectorAll('.option')[selectedAnswer].classList.add('wrong');
            document.querySelectorAll('.option')[currentQuiz[currentQ].ans].classList.add('correct');
        }
    }
    currentQ++;
    if (currentQ >= currentQuiz.length) {
        saveSession('quizResult', { correct: correctCount, wrong: wrongCount, skipped: skippedCount, total: currentQuiz.length });
        clearInterval(timerInterval);
        window.location.href = 'score.html';
    } else {
        renderQuestion();
    }
}

function startTimer() {
    clearInterval(timerInterval);
    timeLeft = currentQuiz.length * 24;
    updateTimerDisplay();
    timerInterval = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            saveSession('quizResult', { correct: correctCount, wrong: wrongCount, skipped: skippedCount, total: currentQuiz.length });
            window.location.href = 'score.html';
        }
    }, 1000);
}

function updateTimerDisplay() {
    const m = String(Math.floor(timeLeft / 60)).padStart(2, '0');
    const s = String(timeLeft % 60).padStart(2, '0');
    document.getElementById('timer-display').textContent = `${m}:${s}`;
}
