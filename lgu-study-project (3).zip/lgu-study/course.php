<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student  = currentStudent();
$studyDB  = getStudyDB();
$courseId = intval($_GET['id'] ?? 0);

if (!$courseId) { header('Location: home.php'); exit; }

// Fetch course
$stmt = $studyDB->prepare("
    SELECT c.course_id, c.course_name, c.description, c.icon, c.credit_hours,
           p.programme_name
    FROM courses c
    JOIN programmes p ON c.programme_id = p.programme_id
    WHERE c.course_id = ? AND p.programme_name = ?
");
$stmt->execute([$courseId, $student['programme']]);
$course = $stmt->fetch();

if (!$course) { header('Location: home.php'); exit; }

// Fetch units
$units = $studyDB->prepare("SELECT * FROM units WHERE course_id = ? ORDER BY unit_number");
$units->execute([$courseId]);
$units = $units->fetchAll();

// Fetch quizzes for this course (via units)
$quizCount = $studyDB->prepare("
    SELECT COUNT(q.quiz_id) AS total
    FROM quizzes q
    JOIN units u ON q.unit_id = u.unit_id
    WHERE u.course_id = ?
");
$quizCount->execute([$courseId]);
$quizCount = $quizCount->fetch()['total'];

// Student's best score for this course
$bestScore = $studyDB->prepare("
    SELECT ROUND(MAX(qa.score / qa.total * 100), 0) AS best
    FROM quiz_attempts qa
    JOIN quizzes q ON qa.quiz_id = q.quiz_id
    JOIN units u   ON q.unit_id  = u.unit_id
    WHERE u.course_id = ? AND qa.student_id = ?
");
$bestScore->execute([$courseId, $student['student_id']]);
$bestScore = $bestScore->fetch()['best'] ?? '—';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — <?= htmlspecialchars($course['course_name']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.course-hero{padding:48px 7% 44px;border-bottom:1px solid var(--color-border);display:flex;align-items:flex-start;justify-content:space-between;gap:40px;}
.course-hero-left{flex:1;}
.course-hero-icon{font-size:36px;margin-bottom:16px;}
.course-hero h2{font-family:var(--font-display);font-size:clamp(28px,4vw,40px);font-weight:400;font-style:italic;letter-spacing:-.5px;margin-bottom:10px;}
.course-hero p{font-size:15px;color:var(--color-muted);max-width:500px;}
.course-hero-actions{display:flex;flex-direction:column;gap:10px;align-items:flex-end;padding-top:4px;}
.course-body{display:flex;flex:1;}
.units-list{flex:1;padding:40px 7%;border-right:1px solid var(--color-border);}
.units-list h3{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--color-muted);margin-bottom:20px;font-weight:400;}
.unit-row{display:flex;align-items:center;gap:16px;padding:18px 20px;border:1px solid var(--color-border);border-radius:10px;margin-bottom:10px;cursor:pointer;background:#fff;transition:border-color .2s,transform .15s;text-decoration:none;color:inherit;}
.unit-row:hover{border-color:var(--color-accent);transform:translateX(4px);}
.unit-num{width:32px;height:32px;border-radius:8px;background:var(--color-surface);border:1px solid var(--color-border);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:500;color:var(--color-muted);flex-shrink:0;font-family:var(--font-display);font-style:italic;}
.unit-row:hover .unit-num{background:var(--color-accent-light);border-color:rgba(200,105,26,.2);color:var(--color-accent);}
.unit-info{flex:1;}
.unit-info h4{font-size:14px;font-weight:500;margin-bottom:2px;}
.unit-info p{font-size:12px;color:var(--color-muted);}
.unit-arrow{color:var(--color-muted);font-size:18px;}
.course-sidebar{width:280px;padding:40px 28px;flex-shrink:0;}
@media(max-width:720px){.course-hero{flex-direction:column;padding:32px 5%;gap:20px;}.course-hero-actions{align-items:flex-start;flex-direction:row;}.course-body{flex-direction:column;}.course-sidebar{width:100%;border-left:none;border-top:1px solid var(--color-border);padding:28px 5%;}.units-list{padding:28px 5%;}}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php"><?= htmlspecialchars($student['initials']) ?></a>
        <a class="btn-ghost" href="php/logout.php">Sign out</a>
    </div>
</nav>

<div class="breadcrumb">
    <a href="home.php">Home</a>
    <span class="sep">/</span>
    <span class="current"><?= htmlspecialchars($course['course_name']) ?></span>
</div>

<div class="course-hero">
    <div class="course-hero-left">
        <div class="course-hero-icon"><?= $course['icon'] ?></div>
        <h2><?= htmlspecialchars($course['course_name']) ?></h2>
        <p><?= htmlspecialchars($course['description']) ?></p>
    </div>
    <div class="course-hero-actions">
        <a class="btn-accent" href="quiz.php?course_id=<?= $courseId ?>">Take Full Course Quiz →</a>
        <button class="btn-ghost">Download Notes</button>
    </div>
</div>

<div class="course-body">
    <div class="units-list">
        <h3>Course Units</h3>
        <?php foreach ($units as $unit): ?>
        <a class="unit-row" href="unit.php?id=<?= $unit['unit_id'] ?>">
            <div class="unit-num"><?= str_pad($unit['unit_number'], 2, '0', STR_PAD_LEFT) ?></div>
            <div class="unit-info">
                <h4><?= htmlspecialchars($unit['unit_title']) ?></h4>
                <p><?= htmlspecialchars($unit['unit_description']) ?></p>
            </div>
            <span class="unit-arrow">›</span>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="course-sidebar">
        <div class="sidebar-card">
            <h4>Your Progress</h4>
            <div class="sidebar-stat"><span>Total units</span><span class="val"><?= count($units) ?></span></div>
            <div class="sidebar-stat"><span>Quizzes available</span><span class="val"><?= $quizCount ?></span></div>
            <div class="sidebar-stat"><span>Best score</span><span class="val" style="color:var(--color-green)"><?= $bestScore ?><?= is_numeric($bestScore) ? '%' : '' ?></span></div>
        </div>
        <div class="sidebar-card">
            <h4>Quick Info</h4>
            <div class="sidebar-stat"><span>Semester</span><span class="val">Sem <?= $student['semester'] ?></span></div>
            <div class="sidebar-stat"><span>Credit hours</span><span class="val"><?= $course['credit_hours'] ?></span></div>
            <div class="sidebar-stat"><span>Year</span><span class="val"><?= $student['year_of_study'] ?><?= ['','st','nd','rd','th'][$student['year_of_study']] ?></span></div>
        </div>
    </div>
</div>
</body>
</html>
