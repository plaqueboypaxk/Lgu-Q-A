<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student = currentStudent();
$studyDB = getStudyDB();
$unitId  = intval($_GET['id'] ?? 0);

if (!$unitId) { header('Location: home.php'); exit; }

// Fetch unit + course info
$stmt = $studyDB->prepare("
    SELECT u.unit_id, u.unit_number, u.unit_title, u.unit_description,
           c.course_id, c.course_name, c.icon
    FROM units u
    JOIN courses c ON u.course_id = c.course_id
    WHERE u.unit_id = ?
");
$stmt->execute([$unitId]);
$unit = $stmt->fetch();

if (!$unit) { header('Location: home.php'); exit; }

// Fetch notes for this unit
$notes = $studyDB->prepare("SELECT * FROM unit_notes WHERE unit_id = ? ORDER BY note_id");
$notes->execute([$unitId]);
$notes = $notes->fetchAll();

// Fetch quiz for this unit (if exists)
$quiz = $studyDB->prepare("SELECT quiz_id FROM quizzes WHERE unit_id = ? LIMIT 1");
$quiz->execute([$unitId]);
$quiz = $quiz->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — <?= htmlspecialchars($unit['unit_title']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.unit-layout{display:flex;flex:1;min-height:calc(100vh - 120px);}
.unit-content{flex:1;padding:48px 7%;}
.unit-content .tag{display:inline-flex;align-items:center;gap:6px;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--color-accent);margin-bottom:16px;font-weight:400;}
.unit-content h2{font-family:var(--font-display);font-size:clamp(28px,4vw,40px);font-weight:400;font-style:italic;letter-spacing:-.5px;margin-bottom:8px;}
.unit-content .meta{font-size:13px;color:var(--color-muted);margin-bottom:40px;}
.notes-body h3{font-family:var(--font-display);font-size:20px;font-weight:400;margin:32px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--color-border);}
.notes-body h3:first-child{margin-top:0;}
.notes-body p{font-size:15px;color:#555;line-height:1.8;margin-bottom:14px;}
.notes-body ul{padding-left:20px;margin-bottom:14px;}
.notes-body li{font-size:15px;color:#555;line-height:1.8;margin-bottom:6px;}
.unit-actions{display:flex;gap:12px;margin-top:48px;padding-top:28px;border-top:1px solid var(--color-border);}
.unit-sidebar{width:260px;border-left:1px solid var(--color-border);padding:40px 24px;flex-shrink:0;}
.unit-sidebar h4{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--color-muted);margin-bottom:16px;font-weight:400;}
@media(max-width:720px){.unit-layout{flex-direction:column;}.unit-content{padding:32px 5%;}.unit-sidebar{width:100%;border-left:none;border-top:1px solid var(--color-border);padding:24px 5%;}}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php"><?= htmlspecialchars($student['initials']) ?></a>
        <a class="btn-ghost" href="php/logout.php">Sign out</a>
    </div>
</nav>

<div class="breadcrumb">
    <a href="home.php">Home</a>
    <span class="sep">/</span>
    <a href="course.php?id=<?= $unit['course_id'] ?>"><?= htmlspecialchars($unit['course_name']) ?></a>
    <span class="sep">/</span>
    <span class="current">Unit <?= $unit['unit_number'] ?></span>
</div>

<div class="unit-layout">
    <div class="unit-content">
        <div class="tag">📖 Unit <?= $unit['unit_number'] ?> Notes</div>
        <h2><?= htmlspecialchars($unit['unit_title']) ?></h2>
        <p class="meta"><?= htmlspecialchars($unit['course_name']) ?> · Unit <?= $unit['unit_number'] ?></p>

        <div class="notes-body">
            <?php if ($notes): ?>
                <?php foreach ($notes as $note): ?>
                    <?= $note['note_content'] ?>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color:var(--color-muted)">Notes for this unit will be available soon. Check back later or download the lecture slides.</p>
            <?php endif; ?>
        </div>

        <div class="unit-actions">
            <?php if ($quiz): ?>
                <a class="btn-accent" href="quiz.php?quiz_id=<?= $quiz['quiz_id'] ?>">Take Unit Quiz →</a>
            <?php else: ?>
                <button class="btn-accent" disabled style="opacity:0.4;cursor:not-allowed;">No Quiz Yet</button>
            <?php endif; ?>
            <a class="btn-outline" href="course.php?id=<?= $unit['course_id'] ?>">← Back to Course</a>
        </div>
    </div>

    <div class="unit-sidebar">
        <h4>Reading Materials</h4>
        <div class="reading-item"><span class="reading-icon">📄</span><div class="reading-info"><h5>Lecture Slides</h5><p>PDF · Available soon</p></div></div>
        <div class="reading-item"><span class="reading-icon">📘</span><div class="reading-info"><h5>Textbook Chapter</h5><p>Reference material</p></div></div>
        <div class="reading-item"><span class="reading-icon">🎥</span><div class="reading-info"><h5>Video Lecture</h5><p>Available soon</p></div></div>
    </div>
</div>
</body>
</html>
