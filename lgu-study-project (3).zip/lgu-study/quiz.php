<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student  = currentStudent();
$studyDB  = getStudyDB();
$quizId   = intval($_GET['quiz_id']   ?? 0);
$courseId = intval($_GET['course_id'] ?? 0);

// Handle quiz submission (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quizId  = intval($_POST['quiz_id'] ?? 0);
    $answers = $_POST['answers'] ?? [];

    if (!$quizId || !$answers) {
        header('Location: home.php'); exit;
    }

    // Fetch correct answers
    $stmt = $studyDB->prepare("
        SELECT q.question_id, o.option_id, o.is_correct
        FROM questions q
        JOIN options o ON o.question_id = q.question_id
        WHERE q.quiz_id = ?
    ");
    $stmt->execute([$quizId]);
    $allOptions = $stmt->fetchAll();

    // Build correct answer map
    $correctMap = [];
    foreach ($allOptions as $opt) {
        if ($opt['is_correct']) {
            $correctMap[$opt['question_id']] = $opt['option_id'];
        }
    }

    // Score the quiz
    $total   = count($correctMap);
    $correct = 0;
    $results = [];

    foreach ($answers as $questionId => $selectedOptionId) {
        $questionId      = intval($questionId);
        $selectedOptionId = intval($selectedOptionId);
        $isCorrect = isset($correctMap[$questionId]) && $correctMap[$questionId] === $selectedOptionId;
        if ($isCorrect) $correct++;
        $results[$questionId] = [
            'selected'   => $selectedOptionId,
            'is_correct' => $isCorrect,
            'correct'    => $correctMap[$questionId] ?? null,
        ];
    }

    // Save attempt
    $stmt = $studyDB->prepare("
        INSERT INTO quiz_attempts (student_id, quiz_id, score, total, taken_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$student['student_id'], $quizId, $correct, $total]);
    $attemptId = $studyDB->lastInsertId();

    // Save individual answers
    $answerStmt = $studyDB->prepare("
        INSERT INTO answers (attempt_id, question_id, selected_option, is_correct)
        VALUES (?, ?, ?, ?)
    ");
    foreach ($results as $questionId => $result) {
        $answerStmt->execute([
            $attemptId,
            $questionId,
            $result['selected'] ?: null,
            $result['is_correct']
        ]);
    }

    // Redirect to score page
    header("Location: score.php?attempt_id=$attemptId");
    exit;
}

// GET — load quiz
if ($courseId) {
    // Full course quiz — get first available quiz across all units in the course
    $stmt = $studyDB->prepare("
        SELECT q.quiz_id, q.quiz_title, q.time_limit
        FROM quizzes q
        JOIN units u ON q.unit_id = u.unit_id
        WHERE u.course_id = ?
        LIMIT 1
    ");
    $stmt->execute([$courseId]);
    $quiz = $stmt->fetch();
} else {
    $stmt = $studyDB->prepare("SELECT * FROM quizzes WHERE quiz_id = ?");
    $stmt->execute([$quizId]);
    $quiz = $stmt->fetch();
}

if (!$quiz) { header('Location: home.php'); exit; }

// Fetch questions + options
$stmt = $studyDB->prepare("
    SELECT q.question_id, q.question_text, q.question_type
    FROM questions q
    WHERE q.quiz_id = ?
    ORDER BY q.question_id
");
$stmt->execute([$quiz['quiz_id']]);
$questions = $stmt->fetchAll();

foreach ($questions as &$question) {
    $optStmt = $studyDB->prepare("SELECT option_id, option_text FROM options WHERE question_id = ?");
    $optStmt->execute([$question['question_id']]);
    $question['options'] = $optStmt->fetchAll();
}
unset($question);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — Quiz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.quiz-wrap{flex:1;display:flex;align-items:flex-start;justify-content:center;padding:52px 7%;}
.quiz-card{width:100%;max-width:660px;background:#fff;border:1px solid var(--color-border2);border-radius:20px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.06);}
.quiz-header{padding:22px 32px;border-bottom:1px solid var(--color-border);display:flex;align-items:center;justify-content:space-between;}
.quiz-header .qinfo{font-size:13px;color:var(--color-muted);}
.quiz-header .qinfo strong{color:var(--color-ink);font-weight:500;}
.timer{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:500;color:var(--color-accent);background:var(--color-accent-light);border:1px solid rgba(200,105,26,.2);padding:6px 14px;border-radius:100px;}
.quiz-progress{height:2px;background:var(--color-surface);}
.quiz-progress-fill{height:100%;background:var(--color-accent);transition:width .4s ease;}
.quiz-body{padding:36px 32px;}
.question-block{display:none;}
.question-block.active{display:block;}
.question-num{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--color-muted);margin-bottom:12px;font-weight:400;}
.question-text{font-family:var(--font-display);font-size:26px;font-weight:400;font-style:italic;line-height:1.3;letter-spacing:-.3px;margin-bottom:32px;}
.options{display:flex;flex-direction:column;gap:10px;}
.option{display:flex;align-items:center;gap:14px;padding:15px 18px;border:1px solid var(--color-border);border-radius:10px;cursor:pointer;background:var(--color-bg);transition:border-color .2s,background .2s;font-size:14px;}
.option:hover{border-color:var(--color-border2);background:var(--color-surface);}
.option.selected{border-color:var(--color-accent);background:var(--color-accent-light);}
.option-letter{width:28px;height:28px;border-radius:6px;background:var(--color-surface);border:1px solid var(--color-border);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:500;flex-shrink:0;color:var(--color-muted);font-family:var(--font-display);font-style:italic;}
.option.selected .option-letter{background:var(--color-accent);border-color:var(--color-accent);color:#fff;}
.quiz-footer{padding:20px 32px;border-top:1px solid var(--color-border);display:flex;justify-content:space-between;align-items:center;}
.btn-next{background:var(--color-ink);color:var(--color-bg);font-family:var(--font-body);font-size:13px;font-weight:500;border:none;border-radius:100px;padding:11px 28px;cursor:pointer;transition:opacity .2s;opacity:.3;pointer-events:none;}
.btn-next.ready{opacity:1;pointer-events:all;}
.btn-next.ready:hover{opacity:.8;}
.btn-submit{background:var(--color-accent);color:#fff;font-family:var(--font-body);font-size:13px;font-weight:500;border:none;border-radius:100px;padding:11px 28px;cursor:pointer;}
.btn-skip{background:transparent;border:none;color:var(--color-muted);font-family:var(--font-body);font-size:13px;cursor:pointer;}
.btn-skip:hover{color:var(--color-ink);}
@media(max-width:720px){.quiz-wrap{padding:24px 5%;}.quiz-body{padding:24px 20px;}.quiz-header,.quiz-footer{padding:16px 20px;}}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php"><?= htmlspecialchars($student['initials']) ?></a>
    </div>
</nav>

<div class="quiz-wrap">
    <div class="quiz-card">
        <div class="quiz-header">
            <div class="qinfo">Question <strong id="q-num">1</strong> of <strong><?= count($questions) ?></strong></div>
            <div class="timer">⏱ <span id="timer-display"><?= gmdate('i:s', $quiz['time_limit']) ?></span></div>
        </div>
        <div class="quiz-progress"><div class="quiz-progress-fill" id="quiz-progress" style="width:<?= round(1/count($questions)*100) ?>%"></div></div>

        <form method="POST" action="quiz.php" id="quiz-form">
            <input type="hidden" name="quiz_id" value="<?= $quiz['quiz_id'] ?>">
            <div class="quiz-body">
                <?php foreach ($questions as $i => $question): ?>
                <div class="question-block <?= $i === 0 ? 'active' : '' ?>" id="q-block-<?= $i ?>">
                    <div class="question-num">Question <?= str_pad($i+1, 2, '0', STR_PAD_LEFT) ?></div>
                    <div class="question-text"><?= htmlspecialchars($question['question_text']) ?></div>
                    <div class="options" id="opts-<?= $i ?>">
                        <?php $letters = ['A','B','C','D','E']; ?>
                        <?php foreach ($question['options'] as $j => $option): ?>
                        <div class="option" onclick="selectOption(<?= $i ?>, <?= $option['option_id'] ?>, this)">
                            <div class="option-letter"><?= $letters[$j] ?></div>
                            <span><?= htmlspecialchars($option['option_text']) ?></span>
                            <input type="radio" name="answers[<?= $question['question_id'] ?>]" value="<?= $option['option_id'] ?>" style="display:none" id="opt-<?= $i ?>-<?= $j ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="quiz-footer">
                <button type="button" class="btn-skip" onclick="nextQuestion()">Skip →</button>
                <button type="button" class="btn-next" id="btn-next" onclick="nextQuestion()">Next Question</button>
            </div>
        </form>
    </div>
</div>

<script>
const totalQ   = <?= count($questions) ?>;
const timeLimit = <?= $quiz['time_limit'] ?>;
let currentQ   = 0;
let timeLeft   = timeLimit;
let selected   = {};

function selectOption(qIndex, optionId, el) {
    document.querySelectorAll(`#opts-${qIndex} .option`).forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    el.querySelector('input[type=radio]').checked = true;
    selected[qIndex] = optionId;
    document.getElementById('btn-next').classList.add('ready');
}

function nextQuestion() {
    if (currentQ < totalQ - 1) {
        document.getElementById(`q-block-${currentQ}`).classList.remove('active');
        currentQ++;
        document.getElementById(`q-block-${currentQ}`).classList.add('active');
        document.getElementById('q-num').textContent = currentQ + 1;
        document.getElementById('quiz-progress').style.width = ((currentQ + 1) / totalQ * 100) + '%';

        const nextBtn = document.getElementById('btn-next');
        if (currentQ === totalQ - 1) {
            nextBtn.textContent = 'Submit Quiz';
            nextBtn.classList.add('ready');
            nextBtn.onclick = () => document.getElementById('quiz-form').submit();
        } else {
            nextBtn.textContent = 'Next Question';
            nextBtn.classList.toggle('ready', selected[currentQ] !== undefined);
            nextBtn.onclick = nextQuestion;
        }
    } else {
        document.getElementById('quiz-form').submit();
    }
}

// Timer
function updateTimer() {
    const m = String(Math.floor(timeLeft / 60)).padStart(2, '0');
    const s = String(timeLeft % 60).padStart(2, '0');
    document.getElementById('timer-display').textContent = `${m}:${s}`;
}
const timerInterval = setInterval(() => {
    timeLeft--;
    updateTimer();
    if (timeLeft <= 0) { clearInterval(timerInterval); document.getElementById('quiz-form').submit(); }
}, 1000);
</script>
</body>
</html>
