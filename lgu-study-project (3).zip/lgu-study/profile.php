<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student = currentStudent();
$studyDB = getStudyDB();

// Stats
$stats = $studyDB->prepare("
    SELECT
        COUNT(DISTINCT qa.quiz_id)                          AS quizzes_done,
        COALESCE(ROUND(AVG(qa.score / qa.total * 100), 0), 0) AS avg_score
    FROM quiz_attempts qa
    WHERE qa.student_id = ?
");
$stats->execute([$student['student_id']]);
$stats = $stats->fetch();

// Course count
$courseCount = $studyDB->prepare("
    SELECT COUNT(*) AS total FROM courses c
    JOIN programmes p ON c.programme_id = p.programme_id
    WHERE p.programme_name = ? AND c.year_offered = ? AND c.semester = ?
");
$courseCount->execute([$student['programme'], $student['year_of_study'], $student['semester']]);
$courseCount = $courseCount->fetch()['total'];

// Unit count
$unitCount = $studyDB->prepare("
    SELECT COUNT(u.unit_id) AS total FROM units u
    JOIN courses c ON u.course_id = c.course_id
    JOIN programmes p ON c.programme_id = p.programme_id
    WHERE p.programme_name = ? AND c.year_offered = ? AND c.semester = ?
");
$unitCount->execute([$student['programme'], $student['year_of_study'], $student['semester']]);
$unitCount = $unitCount->fetch()['total'];

// Recent quiz attempts
$recent = $studyDB->prepare("
    SELECT qa.score, qa.total, qa.taken_at,
           ROUND(qa.score / qa.total * 100, 0) AS pct,
           q.quiz_title, c.course_name
    FROM quiz_attempts qa
    JOIN quizzes q ON qa.quiz_id = q.quiz_id
    JOIN units u   ON q.unit_id  = u.unit_id
    JOIN courses c ON u.course_id = c.course_id
    WHERE qa.student_id = ?
    ORDER BY qa.taken_at DESC
    LIMIT 5
");
$recent->execute([$student['student_id']]);
$recentAttempts = $recent->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — Profile</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.profile-hero{padding:52px 7% 44px;border-bottom:1px solid var(--color-border);display:flex;align-items:center;gap:28px;}
.profile-avatar-lg{width:72px;height:72px;border-radius:50%;background:var(--color-accent);display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:500;color:#fff;flex-shrink:0;}
.profile-hero h2{font-family:var(--font-display);font-size:clamp(28px,4vw,40px);font-weight:400;font-style:italic;letter-spacing:-.5px;margin-bottom:4px;}
.profile-hero p{font-size:13px;color:var(--color-muted);}
.profile-body{padding:44px 7% 72px;}
.activity-list{display:flex;flex-direction:column;gap:10px;margin-top:8px;}
.activity-item{display:flex;align-items:center;gap:16px;padding:16px 20px;background:#fff;border:1px solid var(--color-border);border-radius:10px;}
.activity-icon{font-size:20px;flex-shrink:0;}
.activity-info{flex:1;}
.activity-info p{font-size:14px;font-weight:500;margin-bottom:2px;}
.activity-info span{font-size:12px;color:var(--color-muted);}
.activity-score{font-size:13px;font-weight:500;color:var(--color-green);white-space:nowrap;}
.empty-state{font-size:14px;color:var(--color-muted);padding:24px 0;}
@media(max-width:720px){.profile-hero{padding:36px 5% 32px;flex-direction:column;align-items:flex-start;}.profile-body{padding:32px 5% 48px;}}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php"><?= htmlspecialchars($student['initials']) ?></a>
        <a class="btn-ghost" href="home.php">← Home</a>
        <a class="btn-ghost" href="php/logout.php">Sign out</a>
    </div>
</nav>

<div class="breadcrumb">
    <a href="home.php">Home</a>
    <span class="sep">/</span>
    <span class="current">Profile</span>
</div>

<div class="profile-hero">
    <div class="profile-avatar-lg"><?= htmlspecialchars($student['initials']) ?></div>
    <div>
        <span class="section-label">Student Profile</span>
        <h2><?= htmlspecialchars($student['full_name']) ?></h2>
        <p><?= htmlspecialchars($student['student_id']) ?> · <?= $student['year_of_study'] ?><?= ['','st','nd','rd','th'][$student['year_of_study']] ?> Year · <?= htmlspecialchars($student['programme']) ?></p>
    </div>
</div>

<div class="stats-row">
    <div class="stat-box"><div class="num"><?= $courseCount ?></div><div class="lbl">Courses enrolled</div></div>
    <div class="stat-box"><div class="num"><?= $unitCount ?></div><div class="lbl">Units available</div></div>
    <div class="stat-box"><div class="num"><?= $stats['quizzes_done'] ?></div><div class="lbl">Quizzes completed</div></div>
    <div class="stat-box"><div class="num"><?= $stats['avg_score'] ?>%</div><div class="lbl">Average score</div></div>
</div>

<div class="profile-body">
    <span class="section-label">Recent Quiz Activity</span>
    <div class="activity-list">
        <?php if ($recentAttempts): ?>
            <?php foreach ($recentAttempts as $attempt): ?>
            <div class="activity-item">
                <span class="activity-icon">✅</span>
                <div class="activity-info">
                    <p><?= htmlspecialchars($attempt['quiz_title']) ?></p>
                    <span><?= htmlspecialchars($attempt['course_name']) ?> · <?= date('d M Y', strtotime($attempt['taken_at'])) ?></span>
                </div>
                <span class="activity-score"><?= $attempt['pct'] ?>%</span>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="empty-state">No quiz activity yet. Pick a course and start studying!</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
