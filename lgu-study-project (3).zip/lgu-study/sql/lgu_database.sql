-- =============================================================
--  LGU STUDY SYSTEM — Full Database v2
--  Covers: Students, Courses, Units, Notes, Quizzes,
--          School DB verification, all 4 degree programmes
-- =============================================================

CREATE DATABASE IF NOT EXISTS lgu_study;
USE lgu_study;

-- =============================================================
-- SCHOOL DATABASE (Separate — owned by the university)
-- This simulates the university's main student registry.
-- In production, your PHP would query this via a separate
-- DB connection (different host/credentials).
-- =============================================================

CREATE DATABASE IF NOT EXISTS lgu_school;
USE lgu_school;

CREATE TABLE IF NOT EXISTS school_students (
    student_id      VARCHAR(20)  PRIMARY KEY,
    full_name       VARCHAR(150) NOT NULL,
    date_of_birth   DATE,
    national_id     VARCHAR(30),
    programme       ENUM('Computer Science', 'Law', 'Social Work', 'Business Administration') NOT NULL,
    year_of_study   INT          NOT NULL CHECK (year_of_study BETWEEN 1 AND 4),
    semester        INT          NOT NULL CHECK (semester BETWEEN 1 AND 2),
    enrollment_date DATE         NOT NULL,
    status          ENUM('active', 'suspended', 'graduated', 'deferred') DEFAULT 'active',
    email           VARCHAR(150),
    phone           VARCHAR(20)
);

-- Sample school registry data
INSERT INTO school_students VALUES
('LGU-2024-0001', 'Alex Mwape',    '2003-05-14', 'NRC001', 'Computer Science',       2, 1, '2023-01-10', 'active',    'alex.mwape@lgu.ac.zm',    '0977000001'),
('LGU-2024-0002', 'Sara Banda',    '2004-02-20', 'NRC002', 'Law',                     1, 1, '2024-01-10', 'active',    'sara.banda@lgu.ac.zm',    '0977000002'),
('LGU-2024-0003', 'James Phiri',   '2002-09-03', 'NRC003', 'Computer Science',        3, 2, '2022-01-10', 'active',    'james.phiri@lgu.ac.zm',   '0977000003'),
('LGU-2024-0004', 'Lucy Zulu',     '2003-11-17', 'NRC004', 'Business Administration', 2, 1, '2023-01-10', 'active',    'lucy.zulu@lgu.ac.zm',     '0977000004'),
('LGU-2024-0005', 'Peter Tembo',   '2001-07-29', 'NRC005', 'Law',                     4, 2, '2021-01-10', 'active',    'peter.tembo@lgu.ac.zm',   '0977000005'),
('LGU-2024-0006', 'Grace Mwila',   '2004-03-08', 'NRC006', 'Social Work',             1, 1, '2024-01-10', 'active',    'grace.mwila@lgu.ac.zm',   '0977000006'),
('LGU-2024-0007', 'David Lungu',   '2002-12-22', 'NRC007', 'Social Work',             3, 1, '2022-01-10', 'active',    'david.lungu@lgu.ac.zm',   '0977000007'),
('LGU-2024-0008', 'Mary Chiluba',  '2003-06-11', 'NRC008', 'Business Administration', 2, 2, '2023-01-10', 'active',    'mary.chiluba@lgu.ac.zm',  '0977000008');


-- =============================================================
-- BACK TO THE STUDY SYSTEM DATABASE
-- =============================================================
USE lgu_study;

-- =============================================================
-- 1. STUDENTS  (study system accounts — linked to school DB)
-- =============================================================
CREATE TABLE students (
    student_id    VARCHAR(20)  PRIMARY KEY,         -- must match school_students.student_id
    username      VARCHAR(100) NOT NULL UNIQUE,
    password      VARCHAR(255) NOT NULL,             -- bcrypt hash
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    last_login    TIMESTAMP    NULL
    -- year_of_study & programme are NOT stored here.
    -- They are always fetched live from lgu_school.school_students
    -- to reflect current semester automatically.
);

INSERT INTO students VALUES
('LGU-2024-0001', 'alex.mwape',  '$2y$10$hash1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0002', 'sara.banda',  '$2y$10$hash2xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0003', 'james.phiri', '$2y$10$hash3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0004', 'lucy.zulu',   '$2y$10$hash4xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0005', 'peter.tembo', '$2y$10$hash5xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0006', 'grace.mwila', '$2y$10$hash6xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0007', 'david.lungu', '$2y$10$hash7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW()),
('LGU-2024-0008', 'mary.chiluba','$2y$10$hash8xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', NOW(), NOW());

-- =============================================================
-- 2. PROGRAMMES
-- =============================================================
CREATE TABLE programmes (
    programme_id   INT          PRIMARY KEY AUTO_INCREMENT,
    programme_name VARCHAR(100) NOT NULL UNIQUE,
    duration_years INT          DEFAULT 4
);

INSERT INTO programmes (programme_name, duration_years) VALUES
('Computer Science',       4),
('Law',                    4),
('Social Work',            4),
('Business Administration',4);

-- =============================================================
-- 3. COURSES
-- =============================================================
CREATE TABLE courses (
    course_id      INT          PRIMARY KEY AUTO_INCREMENT,
    programme_id   INT          NOT NULL,
    course_name    VARCHAR(150) NOT NULL,
    description    TEXT,
    year_offered   INT          NOT NULL CHECK (year_offered BETWEEN 1 AND 4),
    semester       INT          NOT NULL CHECK (semester BETWEEN 1 AND 2),
    credit_hours   INT          DEFAULT 3,
    icon           VARCHAR(10)  DEFAULT '📘',
    FOREIGN KEY (programme_id) REFERENCES programmes(programme_id)
);

-- ── COMPUTER SCIENCE ──────────────────────────────────────────
INSERT INTO courses (programme_id, course_name, description, year_offered, semester, credit_hours, icon) VALUES
-- Year 1
(1, 'Introduction to Computing',   'Fundamentals of computers, hardware, software, and basic programming.',              1, 1, 3, '💻'),
(1, 'Mathematics for CS',          'Logic, sets, functions, and discrete mathematics foundations.',                       1, 1, 4, '📐'),
(1, 'Programming Fundamentals',    'Introduction to programming using Python. Variables, loops, and functions.',         1, 2, 3, '🐍'),
(1, 'Computer Organisation',       'CPU architecture, memory systems, and low-level data representation.',               1, 2, 3, '🔧'),
-- Year 2
(1, 'Business Communication',      'Types, models, and strategies for effective communication in professional settings.', 2, 1, 3, '💬'),
(1, 'Data Structures',             'Arrays, linked lists, stacks, queues, trees, and graphs.',                           2, 1, 4, '🔢'),
(1, 'Web Development',             'HTML, CSS, JavaScript, PHP, and database integration.',                              2, 2, 3, '🌐'),
(1, 'Database Management',         'Relational databases, SQL, normalization, and transactions.',                        2, 2, 3, '🗄️'),
-- Year 3
(1, 'Operating Systems',           'Process management, memory, file systems, and concurrency.',                         3, 1, 3, '⚙️'),
(1, 'Computer Networks',           'OSI model, TCP/IP, routing, switching, and network security.',                       3, 1, 3, '📡'),
(1, 'Software Engineering',        'SDLC, agile methods, UML, testing, and project management.',                         3, 2, 3, '🛠️'),
(1, 'Artificial Intelligence',     'Search algorithms, machine learning basics, and neural networks.',                   3, 2, 4, '🤖'),
-- Year 4
(1, 'Cybersecurity',               'Cryptography, network security, ethical hacking, and risk management.',              4, 1, 3, '🔐'),
(1, 'Final Year Project',          'Independent research and development project with a supervisor.',                    4, 2, 6, '🎓');

-- ── LAW ───────────────────────────────────────────────────────
INSERT INTO courses (programme_id, course_name, description, year_offered, semester, credit_hours, icon) VALUES
(2, 'Introduction to Law',         'Basic legal concepts, sources of law, and the Zambian legal system.',               1, 1, 3, '⚖️'),
(2, 'Constitutional Law',          'The Constitution of Zambia, fundamental rights, and separation of powers.',         1, 2, 4, '📜'),
(2, 'Criminal Law',                'Offences, defences, and criminal procedure under Zambian law.',                     2, 1, 3, '🔒'),
(2, 'Law of Contract',             'Formation, terms, breach, and remedies in contract law.',                           2, 1, 3, '📋'),
(2, 'Law of Tort',                 'Negligence, defamation, nuisance, and civil liability.',                            2, 2, 3, '⚠️'),
(2, 'Land Law',                    'Property rights, tenure systems, and land administration in Zambia.',               3, 1, 3, '🏡'),
(2, 'Commercial Law',              'Business entities, agency, sale of goods, and banking law.',                        3, 2, 3, '💼'),
(2, 'Evidence & Procedure',        'Rules of evidence, court procedure, and legal advocacy.',                           4, 1, 4, '🧾'),
(2, 'Dissertation',                'Independent legal research paper on a chosen area of law.',                         4, 2, 6, '🎓');

-- ── SOCIAL WORK ───────────────────────────────────────────────
INSERT INTO courses (programme_id, course_name, description, year_offered, semester, credit_hours, icon) VALUES
(3, 'Introduction to Social Work', 'History, values, ethics, and scope of social work practice.',                       1, 1, 3, '🤝'),
(3, 'Human Behaviour',             'Psychological and social development across the lifespan.',                          1, 2, 3, '🧠'),
(3, 'Social Policy',               'Policy frameworks, welfare systems, and social justice in Zambia.',                  2, 1, 3, '📊'),
(3, 'Community Development',       'Principles and methods of community-based development and empowerment.',             2, 2, 3, '🏘️'),
(3, 'Child & Family Welfare',      'Child protection, family support, and safeguarding frameworks.',                     3, 1, 3, '👨‍👩‍👧'),
(3, 'Research Methods',            'Quantitative and qualitative methods for social research.',                          3, 2, 3, '🔬'),
(3, 'Social Work Practice',        'Field placement and supervised direct practice with clients.',                       4, 1, 4, '🩺'),
(3, 'Dissertation',                'Independent research project in social work or welfare.',                            4, 2, 6, '🎓');

-- ── BUSINESS ADMINISTRATION ────────────────────────────────────
INSERT INTO courses (programme_id, course_name, description, year_offered, semester, credit_hours, icon) VALUES
(4, 'Principles of Management',    'Fundamentals of planning, organising, leading, and controlling.',                   1, 1, 3, '📈'),
(4, 'Business Communication',      'Professional writing, presentations, and workplace communication.',                  1, 2, 3, '💬'),
(4, 'Financial Accounting',        'Double-entry bookkeeping, financial statements, and basic analysis.',               2, 1, 4, '💰'),
(4, 'Marketing Management',        'Market research, consumer behaviour, and marketing strategy.',                      2, 1, 3, '📣'),
(4, 'Human Resource Management',   'Recruitment, training, performance, and employee relations.',                       2, 2, 3, '👥'),
(4, 'Business Law',                'Contract law, company law, and legal aspects of business.',                         3, 1, 3, '⚖️'),
(4, 'Strategic Management',        'Competitive analysis, corporate strategy, and implementation.',                     3, 2, 3, '♟️'),
(4, 'Entrepreneurship',            'Business planning, venture creation, funding, and growth.',                         4, 1, 3, '🚀'),
(4, 'Business Research Project',   'Applied business research with industry partner or case study.',                    4, 2, 6, '🎓');

-- =============================================================
-- 4. UNITS
-- =============================================================
CREATE TABLE units (
    unit_id          INT          PRIMARY KEY AUTO_INCREMENT,
    course_id        INT          NOT NULL,
    unit_number      INT          NOT NULL,
    unit_title       VARCHAR(200) NOT NULL,
    unit_description TEXT,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- Units for Business Communication (course_id = 5 — CS Year 2)
INSERT INTO units (course_id, unit_number, unit_title, unit_description) VALUES
(5, 1, 'Types of Communication',    'Verbal, non-verbal, formal, and informal communication.'),
(5, 2, 'Ways to Communicate',       'Channels and mediums — face-to-face, digital, written.'),
(5, 3, 'Communication Models',      'Shannon-Weaver, Berlo, and transactional models.'),
(5, 4, 'Barriers to Communication', 'Physical, psychological, language, and cultural barriers.'),
(5, 5, 'Written Communication',     'Reports, memos, emails, and professional writing.'),
(5, 6, 'Presentation Skills',       'Planning, delivery, visual aids, and handling questions.');

-- Units for Data Structures (course_id = 6)
INSERT INTO units (course_id, unit_number, unit_title, unit_description) VALUES
(6, 1, 'Arrays & Strings',          'Static data structures, indexing, and string manipulation.'),
(6, 2, 'Linked Lists',              'Singly, doubly, and circular linked lists.'),
(6, 3, 'Stacks & Queues',           'LIFO and FIFO structures with real-world applications.'),
(6, 4, 'Trees & Binary Trees',      'Tree traversal, BST, and AVL trees.'),
(6, 5, 'Graphs',                    'Directed/undirected graphs, BFS, and DFS.'),
(6, 6, 'Hash Tables',               'Hash functions, collision resolution, and performance.'),
(6, 7, 'Sorting Algorithms',        'Bubble, merge, quick sort and time complexity.'),
(6, 8, 'Big-O Analysis',            'Measuring time and space complexity.');

-- Units for Web Development (course_id = 7)
INSERT INTO units (course_id, unit_number, unit_title, unit_description) VALUES
(7, 1, 'HTML Fundamentals',         'Structure, tags, forms, and semantic HTML.'),
(7, 2, 'CSS Layouts & Styling',     'Box model, flexbox, grid, and responsive design.'),
(7, 3, 'JavaScript Basics',         'Variables, functions, events, and DOM basics.'),
(7, 4, 'DOM Manipulation',          'Selecting, creating, and modifying DOM elements.'),
(7, 5, 'PHP & Server-side',         'Syntax, forms, sessions, and server logic.'),
(7, 6, 'MySQL Integration',         'Connecting PHP to MySQL, CRUD operations.'),
(7, 7, 'Full-stack Project',        'Building a complete web application end-to-end.');

-- =============================================================
-- 5. UNIT NOTES
-- =============================================================
CREATE TABLE unit_notes (
    note_id      INT          PRIMARY KEY AUTO_INCREMENT,
    unit_id      INT          NOT NULL,
    note_title   VARCHAR(200) NOT NULL,
    note_content LONGTEXT     NOT NULL,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (unit_id) REFERENCES units(unit_id) ON DELETE CASCADE
);

INSERT INTO unit_notes (unit_id, note_title, note_content) VALUES
(1, 'Types of Communication',
'<h3>What is Communication?</h3>
<p>Communication is the process of transferring information, ideas, feelings, and thoughts between a sender and a receiver through a chosen medium.</p>
<h3>Verbal Communication</h3>
<p>Uses spoken or written words. Includes face-to-face conversations, phone calls, presentations, and written correspondence.</p>
<ul><li>Oral — speeches, meetings, interviews</li><li>Written — emails, reports, letters</li></ul>
<h3>Non-Verbal Communication</h3>
<p>Signals conveyed without words — body language, facial expressions, eye contact, posture. Over 70% of communication is estimated to be non-verbal.</p>
<h3>Formal vs Informal</h3>
<p>Formal follows official channels — memos, reports, official meetings. Informal is spontaneous — hallway conversations, messaging apps.</p>'),

(2, 'Ways to Communicate',
'<h3>Communication Channels</h3>
<p>A channel is the medium through which a message travels. Choosing the right channel is essential for effective communication.</p>
<h3>Face-to-Face</h3>
<p>The richest channel. Allows for immediate feedback, non-verbal cues, and emotional connection.</p>
<h3>Digital Communication</h3>
<p>Email, messaging apps, video calls. Enables asynchronous communication across distances.</p>
<ul><li>Email — formal, documented, asynchronous</li><li>Messaging — quick, informal, real-time</li><li>Video calls — combines visual and audio remotely</li></ul>');

-- =============================================================
-- 6. QUIZZES
-- =============================================================
CREATE TABLE quizzes (
    quiz_id      INT          PRIMARY KEY AUTO_INCREMENT,
    unit_id      INT          NOT NULL,
    quiz_title   VARCHAR(200) NOT NULL,
    time_limit   INT          DEFAULT 120,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (unit_id) REFERENCES units(unit_id) ON DELETE CASCADE
);

INSERT INTO quizzes (unit_id, quiz_title, time_limit) VALUES
(1, 'Types of Communication Quiz', 120),
(2, 'Ways to Communicate Quiz',    120),
(3, 'Communication Models Quiz',   120),
(4, 'Barriers to Communication Quiz', 120),
(5, 'Written Communication Quiz',  120),
(6, 'Presentation Skills Quiz',    120);

-- =============================================================
-- 7. QUESTIONS
-- =============================================================
CREATE TABLE questions (
    question_id   INT          PRIMARY KEY AUTO_INCREMENT,
    quiz_id       INT          NOT NULL,
    question_text TEXT         NOT NULL,
    question_type ENUM('mcq','true_false') DEFAULT 'mcq',
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE
);

-- Quiz 1 — Types of Communication
INSERT INTO questions (quiz_id, question_text, question_type) VALUES
(1, 'Which type of communication involves body language and facial expressions?', 'mcq'),
(1, 'What percentage of communication is estimated to be non-verbal?', 'mcq'),
(1, 'Which of the following is an example of formal communication?', 'mcq'),
(1, 'In the communication process, who encodes the message?', 'mcq'),
(1, 'Verbal communication only refers to spoken words.', 'true_false');

-- Quiz 2 — Ways to Communicate
INSERT INTO questions (quiz_id, question_text, question_type) VALUES
(2, 'Which communication channel is considered the richest?', 'mcq'),
(2, 'What is a key advantage of email over face-to-face communication?', 'mcq'),
(2, 'Asynchronous communication requires both parties to be available at the same time.', 'true_false'),
(2, 'Which is an example of informal digital communication?', 'mcq'),
(2, 'What should guide your choice of communication channel?', 'mcq');

-- =============================================================
-- 8. OPTIONS
-- =============================================================
CREATE TABLE options (
    option_id    INT     PRIMARY KEY AUTO_INCREMENT,
    question_id  INT     NOT NULL,
    option_text  TEXT    NOT NULL,
    is_correct   BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- Q1
INSERT INTO options (question_id, option_text, is_correct) VALUES
(1,'Verbal communication',FALSE),(1,'Non-verbal communication',TRUE),(1,'Written communication',FALSE),(1,'Formal communication',FALSE);
-- Q2
INSERT INTO options (question_id, option_text, is_correct) VALUES
(2,'20%',FALSE),(2,'45%',FALSE),(2,'Over 70%',TRUE),(2,'90%',FALSE);
-- Q3
INSERT INTO options (question_id, option_text, is_correct) VALUES
(3,'A text message to a friend',FALSE),(3,'A hallway conversation',FALSE),(3,'An official memo to staff',TRUE),(3,'A social media post',FALSE);
-- Q4
INSERT INTO options (question_id, option_text, is_correct) VALUES
(4,'The receiver',FALSE),(4,'The medium',FALSE),(4,'The sender',TRUE),(4,'The feedback',FALSE);
-- Q5 (true/false)
INSERT INTO options (question_id, option_text, is_correct) VALUES
(5,'True',FALSE),(5,'False',TRUE);
-- Q6
INSERT INTO options (question_id, option_text, is_correct) VALUES
(6,'Email',FALSE),(6,'Text message',FALSE),(6,'Face-to-face',TRUE),(6,'Phone call',FALSE);
-- Q7
INSERT INTO options (question_id, option_text, is_correct) VALUES
(7,'It is more personal',FALSE),(7,'It provides a written record',TRUE),(7,'It allows instant replies',FALSE),(7,'It uses non-verbal cues',FALSE);
-- Q8 (true/false)
INSERT INTO options (question_id, option_text, is_correct) VALUES
(8,'True',FALSE),(8,'False',TRUE);
-- Q9
INSERT INTO options (question_id, option_text, is_correct) VALUES
(9,'An official memo',FALSE),(9,'A board meeting',FALSE),(9,'An instant message to a colleague',TRUE),(9,'A formal report',FALSE);
-- Q10
INSERT INTO options (question_id, option_text, is_correct) VALUES
(10,'Your personal preference',FALSE),(10,'The nature and urgency of the message',TRUE),(10,'How long the message is',FALSE),(10,'The number of recipients',FALSE);

-- =============================================================
-- 9. QUIZ ATTEMPTS
-- =============================================================
CREATE TABLE quiz_attempts (
    attempt_id   INT         PRIMARY KEY AUTO_INCREMENT,
    student_id   VARCHAR(20) NOT NULL,
    quiz_id      INT         NOT NULL,
    score        INT         DEFAULT 0,
    total        INT         DEFAULT 0,
    taken_at     TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id)    REFERENCES quizzes(quiz_id)     ON DELETE CASCADE
);

INSERT INTO quiz_attempts (student_id, quiz_id, score, total) VALUES
('LGU-2024-0001', 1, 4, 5),
('LGU-2024-0001', 2, 3, 5),
('LGU-2024-0003', 1, 5, 5);

-- =============================================================
-- 10. ANSWERS
-- =============================================================
CREATE TABLE answers (
    answer_id       INT     PRIMARY KEY AUTO_INCREMENT,
    attempt_id      INT     NOT NULL,
    question_id     INT     NOT NULL,
    selected_option INT,
    is_correct      BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (attempt_id)      REFERENCES quiz_attempts(attempt_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id)     REFERENCES questions(question_id)    ON DELETE CASCADE,
    FOREIGN KEY (selected_option) REFERENCES options(option_id)        ON DELETE SET NULL
);


-- =============================================================
-- VIEWS
-- =============================================================

-- Student's current courses (fetched via school DB year + programme)
CREATE OR REPLACE VIEW student_course_view AS
SELECT
    s.student_id,
    ss.full_name,
    ss.programme,
    ss.year_of_study,
    ss.semester,
    c.course_id,
    c.course_name,
    c.description,
    c.icon,
    c.credit_hours
FROM lgu_study.students s
JOIN lgu_school.school_students ss ON s.student_id = ss.student_id
JOIN lgu_study.courses c
    ON c.year_offered = ss.year_of_study
    AND c.semester    = ss.semester
JOIN lgu_study.programmes p
    ON c.programme_id = p.programme_id
    AND p.programme_name = ss.programme
WHERE ss.status = 'active';

-- Quiz results per student
CREATE OR REPLACE VIEW student_quiz_results AS
SELECT
    ss.full_name,
    qa.student_id,
    ss.programme,
    q.quiz_title,
    qa.score,
    qa.total,
    ROUND((qa.score / qa.total) * 100, 1) AS percentage,
    qa.taken_at
FROM lgu_study.quiz_attempts qa
JOIN lgu_school.school_students ss ON qa.student_id = ss.student_id
JOIN lgu_study.quizzes q           ON qa.quiz_id    = q.quiz_id;

-- =============================================================
-- PHP VERIFICATION SNIPPET
-- Paste this in your PHP login/register handler.
-- It checks the school DB before allowing account creation.
-- =============================================================
/*

<?php
// db_config.php — two connections
$study_db  = new PDO("mysql:host=localhost;dbname=lgu_study",  $user, $pass);
$school_db = new PDO("mysql:host=localhost;dbname=lgu_school", $user, $pass);

// On REGISTER — verify student exists in school DB
function verifyStudent($student_id, $school_db) {
    $stmt = $school_db->prepare("
        SELECT student_id, full_name, programme, year_of_study, semester, status
        FROM school_students
        WHERE student_id = ? AND status = 'active'
    ");
    $stmt->execute([$student_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// On LOGIN — fetch current year/semester from school DB
function getStudentProfile($student_id, $school_db) {
    $stmt = $school_db->prepare("
        SELECT full_name, programme, year_of_study, semester
        FROM school_students
        WHERE student_id = ?
    ");
    $stmt->execute([$student_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch correct courses for this student after login
function getStudentCourses($student_id, $study_db, $profile) {
    $stmt = $study_db->prepare("
        SELECT c.course_id, c.course_name, c.description, c.icon, c.credit_hours
        FROM courses c
        JOIN programmes p ON c.programme_id = p.programme_id
        WHERE p.programme_name = ?
          AND c.year_offered    = ?
          AND c.semester        = ?
    ");
    $stmt->execute([$profile['programme'], $profile['year_of_study'], $profile['semester']]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

*/
