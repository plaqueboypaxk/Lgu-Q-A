<?php
require_once 'includes/db.php';
require_once 'includes/session.php';
requireLogin();

$student   = currentStudent();
$studyDB   = getStudyDB();
$attemptId = intval($_GET['attempt_id'] ?? 0);

if (!$attemptId) { header('Location: home.php'); exit; }

// Fetch attempt
$stmt = $studyDB->prepare("
    SELECT qa.*, q.quiz_title, u.course_id
    FROM quiz_attempts qa
    JOIN quizzes q ON qa.quiz_id = q.quiz_id
    JOIN units u   ON q.unit_id  = u.unit_id
    WHERE qa.attempt_id = ? AND qa.student_id = ?
");
$stmt->execute([$attemptId, $student['student_id']]);
$attempt = $stmt->fetch();

if (!$attempt) { header('Location: home.php'); exit; }

$pct     = $attempt['total'] > 0 ? round($attempt['score'] / $attempt['total'] * 100) : 0;
$skipped = $attempt['total'] - $attempt['score'] - ($attempt['total'] - $attempt['score']);

// Fetch answer breakdown
$answers = $studyDB->prepare("
    SELECT a.question_id, a.is_correct, a.selected_option,
           q.question_text,
           o.option_text AS selected_text,
           co.option_text AS correct_text
    FROM answers a
    JOIN questions q ON a.question_id = q.question_id
    LEFT JOIN options o  ON a.selected_option = o.option_id
    LEFT JOIN options co ON co.question_id = q.question_id AND co.is_correct = 1
    WHERE a.attempt_id = ?
");
$answers->execute([$attemptId]);
$answers = $answers->fetchAll();

$wrong   = count(array_filter($answers, fn($a) => !$a['is_correct'] && $a['selected_option']));
$skipped = count(array_filter($answers, fn($a) => !$a['selected_option']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LGU Study — Score</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.score-wrap{flex:1;display:flex;flex-direction:column;align-items:center;padding:52px 7%;}
.score-card{width:500px;max-width:100%;background:#fff;border:1px solid var(--color-border2);border-radius:24px;padding:56px 52px;text-align:center;box-shadow:0 8px 40px rgba(0,0,0,.06);margin-bottom:32px;}
.score-ring{width:120px;height:120px;margin:0 auto 28px;position:relative;}
.score-ring svg{width:100%;height:100%;transform:rotate(-90deg);}
.score-ring .bg-circle{fill:none;stroke:var(--color-surface);stroke-width:5;}
.score-ring .fg-circle{fill:none;stroke:var(--color-accent);stroke-width:5;stroke-linecap:round;stroke-dasharray:283;stroke-dashoffset:283;transition:stroke-dashoffset 1.2s ease;}
.score-num{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:var(--font-display);font-size:30px;font-style:italic;}
.score-num small{font-family:var(--font-body);font-size:11px;color:var(--color-muted);font-style:normal;margin-top:-2px;}
.score-card h2{font-family:var(--font-display);font-size:28px;font-weight:400;font-style:italic;margin-bottom:8px;letter-spacing:-.3px;}
.score-card > p{font-size:14px;color:var(--color-muted);margin-bottom:32px;}
.score-breakdown{display:flex;background:var(--color-bg);border:1px solid var(--color-border);border-radius:10px;overflow:hidden;margin-bottom:28px;}
.breakdown-item{flex:1;padding:16px 12px;text-align:center;border-right:1px solid var(--color-border);}
.breakdown-item:last-child{border-right:none;}
.breakdown-item .bval{font-family:var(--font-display);font-size:22px;font-style:italic;margin-bottom:2px;}
.breakdown-item .blbl{font-size:11px;color:var(--color-muted);text-transform:uppercase;letter-spacing:.08em;}
.score-actions{display:flex;gap:10px;}
.score-actions a{flex:1;text-align:center;}
.review-section{width:500px;max-width:100%;}
.review-section h3{font-family:var(--font-display);font-size:20px;font-style:italic;margin-bottom:16px;}
.review-item{background:#fff;border:1px solid var(--color-border);border-radius:10px;padding:16px 20px;margin-bottom:10px;}
.review-item.correct{border-left:3px solid var(--color-green);}
.review-item.wrong{border-left:3px solid var(--color-red);}
.review-item.skipped{border-left:3px solid var(--color-muted);}
.review-item p{font-size:14px;font-weight:500;margin-bottom:8px;}
.review-item span{font-size:12px;color:var(--color-muted);}
.review-item .correct-ans{color:var(--color-green);font-weight:500;}
.review-item .wrong-ans{color:var(--color-red);}
@media(max-width:720px){.score-card,.review-section{width:100%;}.score-card{padding:40px 28px;}}
</style>
</head>
<body>
<div class="grain"></div>
<nav class="app-nav">
    <a class="nav-logo" href="home.php">LGU <em>Study.</em></a>
    <div class="nav-right">
        <span style="font-size:13px;color:var(--color-muted);"><?= htmlspecialchars($student['full_name']) ?></span>
        <a class="avatar" href="profile.php"><?= htmlspecialchars($student['initials']) ?></a>
    </div>
</nav>

<div class="score-wrap">
    <div class="score-card">
        <div class="score-ring">
            <svg viewBox="0 0 100 100">
                <circle class="bg-circle" cx="50" cy="50" r="45"/>
                <circle class="fg-circle" id="score-circle" cx="50" cy="50" r="45"/>
            </svg>
            <div class="score-num"><span><?= $pct ?>%</span><small>score</small></div>
        </div>
        <h2><?= $pct >= 80 ? 'Excellent work!' : ($pct >= 60 ? 'Good effort!' : 'Keep practicing!') ?></h2>
        <p><?= $pct >= 80 ? 'You have a strong grasp of this material.' : ($pct >= 60 ? 'Review the missed questions and try again.' : 'Re-read the notes and attempt the quiz again.') ?></p>
        <div class="score-breakdown">
            <div class="breakdown-item"><div class="bval" style="color:var(--color-green)"><?= $attempt['score'] ?></div><div class="blbl">Correct</div></div>
            <div class="breakdown-item"><div class="bval" style="color:var(--color-red)"><?= $wrong ?></div><div class="blbl">Wrong</div></div>
            <div class="breakdown-item"><div class="bval" style="color:var(--color-muted)"><?= $skipped ?></div><div class="blbl">Skipped</div></div>
        </div>
        <div class="score-actions">
            <a class="btn-outline" href="quiz.php?quiz_id=<?= $attempt['quiz_id'] ?>">Retry Quiz</a>
            <a class="btn-accent" href="home.php" style="border-radius:100px;padding:11px 26px;">Back to Home</a>
        </div>
    </div>

    <!-- Answer Review -->
    <div class="review-section">
        <h3>Answer Review</h3>
        <?php foreach ($answers as $i => $answer): ?>
        <div class="review-item <?= $answer['selected_option'] ? ($answer['is_correct'] ? 'correct' : 'wrong') : 'skipped' ?>">
            <p><?= ($i+1) ?>. <?= htmlspecialchars($answer['question_text']) ?></p>
            <?php if (!$answer['selected_option']): ?>
                <span>Skipped</span>
            <?php elseif ($answer['is_correct']): ?>
                <span class="correct-ans">✓ <?= htmlspecialchars($answer['selected_text']) ?></span>
            <?php else: ?>
                <span class="wrong-ans">✗ You answered: <?= htmlspecialchars($answer['selected_text']) ?></span><br>
                <span class="correct-ans">✓ Correct: <?= htmlspecialchars($answer['correct_text']) ?></span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
setTimeout(() => {
    document.getElementById('score-circle').style.strokeDashoffset = 283 - (<?= $pct ?> / 100) * 283;
}, 100);
</script>
</body>
</html>
